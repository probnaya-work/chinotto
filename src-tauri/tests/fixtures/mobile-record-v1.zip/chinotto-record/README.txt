Chinotto Record export

record.txt is readable in date order. record.jsonl contains one JSON object per moment, including correction history, relationships, source metadata and audio filenames. audio/ contains original retained recordings. archived.jsonl contains older user-authored material preserved through migration. Restore this archive in a current Chinotto build to add its moments without replacing an existing Record. It contains private material; keep it somewhere you trust.
